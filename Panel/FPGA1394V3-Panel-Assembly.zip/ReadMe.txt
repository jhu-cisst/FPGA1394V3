These files contain the necessary information to assemble a PCB.

Board Name: IEEE-1394/Ethernet FPGA Board, Rev 3.1
Release Date: 09/14/2022

The files included are:
1-  ReadMe.txt             This file
2-  FPGA3_1-Panel.GTP      Top side paste mask
3-  FPGA3_1-Panel.GBP      Bottom side paste mask
4-  FPGA3_1-PCB.txt        Board file in Text Format
5-  FPGA3_1-Assembly.pdf   Assembly Drawing
6-  FPGA3_1-Panel-ODB.zip  Board in OBD Format

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

2) Except 0201, apertures in the paste mask are the same size as the PCB pads.

3) For 0201, apertures are approximately 30% larger than the pad size.

4) Larger pads have been windowed.
