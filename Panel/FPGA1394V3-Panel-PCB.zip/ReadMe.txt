These files contain the necessary information to manufacture a
printed circuit board.

Board Name: IEEE-1394/Ethernet FPGA Board, Rev 3.2
Release Date: 09/04/2024

The files included are:
1-  ReadME.txt               This file
2-  FPGA3-Panel.GTL          Top side routing layer
3-  FPGA3-Panel.GBL          Bottom side routing layer
4-  FPGA3-Panel.GP1          Internal Plane 1
5-  FPGA3-Panel.GP2          Internal Plane 2
6-  FPGA3-Panel.GP3          Internal Plane 3
7-  FPGA3-Panel.GP4          Internal Plane 4
8-  FPGA3-Panel.GP5          Internal Plane 5
9-  FPGA3-Panel.GP6          Internal Plane 6
10- FPGA3-Panel.G1           Internal Layer 1
11- FPGA3-Panel.G2           Internal Layer 2
12- FPGA3-Panel.G3           Internal Layer 3
13- FPGA3-Panel.G4           Internal Layer 4
14- FPGA3-Panel.GTO          Top side silk screen mask
15- FPGA3-Panel.GBO          Bottom side silk screen mask
16- FPGA3-Panel.GTS          Top side solder mask
17- FPGA3-Panel.GBS          Bottom side solder mask
18- FPGA3-Panel.GM1          Mechanical drawing of board outline and slots.
19- FPGA3-Panel-Holes.TXT    Text of drill file for holes
20- FPGA3-Panel-Slots.TXT    Text of drill file for slots
21- FPGA3-Panel.IPC          IPC-D-356A Netlist
22- FPGA3-Panel.PDF          Drill and fabrication drawing
23- FPGA3-Panel-Stackup.pdf  Stackup drawing

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

FAB INSTRUCTIONS:
- Vendor and process shall be UL 94V-0 approved.
- Boards must be individually marked with vender identification and UL 94V-0
- Material: FR4
- Vias: Top-Bottom only.
- Solder mask: LPI   Color: green
- Silkscreen on both sides. Color: white
- Fab tolerance:  See fabrication drawing
- Layer Sequence: See fabrication drawing
- Copper Weight:  See fabrication drawing
- Thickness:      See fabrication drawing
